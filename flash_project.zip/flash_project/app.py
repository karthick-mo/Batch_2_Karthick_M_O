print("flash project")
from flask import Flask,render_template 

app = Flask(__name__)

@app.route('/')
def hello_world():
    return render_template('index.html')

@app.route('/about',methods=['GET'])
def about():
    return render_template('about.html')

@app.route('/downloads',methods=['GET'])
def downloads():
    return render_template('downloads.html')

@app.route('/documentation',methods=['GET'])
def documentation():
    return render_template('documentation.html')

@app.route('/community',methods=['GET'])
def community():
    return render_template('community.html')

@app.route('/news',methods=['GET'])
def news():
    return render_template('news.html')

@app.route('/events',methods=['GET'])
def events():
    return render_template('events.html')

if __name__ == '__main__':
    app.run(debug=True)