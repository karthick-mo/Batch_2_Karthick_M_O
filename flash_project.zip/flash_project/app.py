from flask import Flask, render_template, request, flash, redirect, url_for

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-this-in-production'

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/events')
def events():
    return render_template('events.html')

@app.route('/community')
def community():
    return render_template('community.html')

@app.route('/news')
def news():
    return render_template('news.html')

@app.route('/documentation')
def documentation():
    return render_template('documnetation.html')

@app.route('/about', methods=['GET', 'POST'])
def about():
    if request.method == 'POST':
        # Handle contact form submission
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        company = request.form.get('company')
        newsletter = request.form.get('newsletter')
        
        # Basic validation
        if name and email and subject and message:
            # Here you can add logic to save to database or send email
            # For now, we'll just flash a success message
            flash(f'Thank you {name}! Your message has been received. We will get back to you soon.', 'success')
        else:
            flash('Please fill in all required fields.', 'error')
        
        return redirect(url_for('about'))
    
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)